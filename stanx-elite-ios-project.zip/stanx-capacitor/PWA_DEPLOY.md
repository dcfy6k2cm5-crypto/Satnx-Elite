# Installing Stanx Elite as a PWA (no App Store required)

The files in `www/` already include everything needed to make this
installable straight from Safari — a manifest, icons, and an offline
service worker. The one thing it needs that this sandbox can't provide is
**real HTTPS hosting** — "Add to Home Screen" only registers a service
worker over `https://`, not a local file.

## Fastest free hosting options

**GitHub Pages** (free, simplest if you already use GitHub)
1. Create a new GitHub repo, upload everything inside `www/` to the repo root.
2. Repo Settings → Pages → set source to the `main` branch.
3. You'll get a URL like `https://yourname.github.io/stanx-elite/`.

**Netlify** (free, drag-and-drop, no account needed for a quick deploy)
1. Go to [app.netlify.com/drop](https://app.netlify.com/drop).
2. Drag the `www` folder onto the page.
3. Netlify gives you a live HTTPS URL instantly.

## Installing it once it's hosted

- **iPhone**: open the URL in Safari → tap the Share icon → "Add to Home
  Screen." It installs with the Stanx Elite icon and opens full-screen,
  no browser bar.
- **Android**: open the URL in Chrome → menu → "Install app."

This gets you a real home-screen app today, with zero App Store review,
zero developer fee. The tradeoff is it won't show up in App Store search —
people need the link (or a QR code) to install it.
