# Stanx Elite — iOS App Setup

This folder is a ready-to-go **Capacitor** project. It wraps the Stanx Elite
web app (in `www/`) into a real native iOS app you can submit to the App Store.

Everything here can run on a Mac. Capacitor/Xcode builds can't run in this
sandbox, so these are the exact steps to run yourself.

## What's in this folder

```
stanx-capacitor/
├── package.json
├── capacitor.config.json
├── README.md (this file)
└── www/                  ← the actual app
    ├── index.html
    ├── manifest.json
    ├── service-worker.js
    └── icons/
```

## Part 1 — Get it running as a native iOS project

**Requirements:** a Mac, [Xcode](https://apps.apple.com/us/app/xcode/id497799835)
(free, from the Mac App Store), and [Node.js](https://nodejs.org) installed.

1. Unzip this project and open Terminal in the `stanx-capacitor` folder.
2. Install dependencies:
   ```
   npm install
   ```
3. Add the iOS platform:
   ```
   npx cap add ios
   ```
   This generates an `ios/` folder containing a full Xcode project.
4. Open it in Xcode:
   ```
   npx cap open ios
   ```
5. In Xcode, pick your iPhone or a simulator from the device dropdown and hit
   the ▶ Play button. The app should launch — this is the same app you've
   been previewing, now running natively.

Any time you update `www/index.html`, re-run `npx cap sync` to push the
changes into the Xcode project.

## Part 2 — Submit to the App Store

1. **Enroll in the Apple Developer Program** — $99/year, at
   [developer.apple.com/programs](https://developer.apple.com/programs/).
   You'll need a legal entity name to publish under (you, or "Stanx Elite" as
   a sole proprietorship — Apple allows individual developer accounts).
2. **Set your Bundle ID and signing team** in Xcode: select the project in
   the left sidebar → Signing & Capabilities → choose your team (created
   automatically once you're enrolled).
3. **App icons**: the icons in `www/icons/` are placeholders in your brand
   colors. Apple requires a full icon set (down to 20x20) — easiest way is
   to drop `icon-1024.png` into Xcode's asset catalog and let it generate
   the rest, or use a tool like [appicon.co](https://appicon.co).
4. **Create the App Store listing** in
   [App Store Connect](https://appstoreconnect.apple.com/): app name,
   screenshots (Xcode simulator can generate these), description, privacy
   info (this app collects no personal data unless you add the fundraising
   button to a real payment link), and category (Sports).
5. **Archive & upload**: in Xcode, Product → Archive, then follow the
   prompts to upload to App Store Connect.
6. **Submit for review** — Apple's review usually takes 1–3 days. Common
   rejection reasons for simple team apps: missing privacy policy URL,
   placeholder content, or broken links — make sure the fundraising numbers
   and any external links are real before submitting.

## Notes

- The `www/` folder is also a valid **PWA** on its own — see the separate
  PWA deployment notes if you just want people to install it from Safari
  without going through the App Store at all.
- The fundraising counter currently resets each time the app is closed
  (it's in-memory only). If you want it to persist and be visible to real
  donors across devices, that needs a small backend — ask if you want that
  built out.
